-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.28-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for flight
DROP DATABASE IF EXISTS `flight`;
CREATE DATABASE IF NOT EXISTS `flight` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `flight`;

-- Dumping structure for table flight.airfield
DROP TABLE IF EXISTS `airfield`;
CREATE TABLE IF NOT EXISTS `airfield` (
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contry` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.airfield: ~4 rows (approximately)
REPLACE INTO `airfield` (`date_create`, `date_modify`, `id`, `address`, `contry`, `name`, `name_create`, `name_modify`) VALUES
	('2023-11-06 11:09:48.000000', '2023-11-06 11:09:48.000000', 17, '22/22 Tân bình TP Hồ Chí Minh', 'Việt  Nam', 'Tân sân nhất', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-06 11:10:23.000000', '2023-11-06 11:10:23.000000', 18, '33/22 Hàm Hương Hà Nội', 'Việt  Nam', 'Nội Bài', 'EWOFOEKOP', 'EWOFOEKOP'),
	(NULL, '2023-11-18 22:20:02.000000', 19, '11/22 Tay Nam Đà Lạt', 'Việt  Nam', 'Đà lạt', NULL, 'EWOFOEKOP');

-- Dumping structure for table flight.airplane
DROP TABLE IF EXISTS `airplane`;
CREATE TABLE IF NOT EXISTS `airplane` (
  `size` int(11) DEFAULT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `trademark_id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKm0v5yg7gexvry4t7lh743uset` (`trademark_id`),
  CONSTRAINT `FKm0v5yg7gexvry4t7lh743uset` FOREIGN KEY (`trademark_id`) REFERENCES `trademark` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.airplane: ~6 rows (approximately)
REPLACE INTO `airplane` (`size`, `date_create`, `date_modify`, `id`, `trademark_id`, `name`, `name_create`, `name_modify`, `status`) VALUES
	(12, NULL, '2023-11-06 11:15:20.000000', 42, 21, 'KLKK', NULL, 'EWOFOEKOP', 'action'),
	(18, NULL, '2023-11-19 20:12:05.000000', 55, 22, 'BBB', NULL, 'EWOFOEKOP', 'stop'),
	(12, NULL, '2023-11-06 11:15:05.000000', 68, 23, 'MMM', NULL, 'EWOFOEKOP', 'action'),
	(12, NULL, '2023-11-06 11:15:12.000000', 81, 24, 'LLL', NULL, 'EWOFOEKOP', 'action'),
	(30, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 155, 23, 'OOOO', 'EWOFOEKOP', 'EWOFOEKOP', 'action'),
	(12, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 246, 20, 'BBB', 'EWOFOEKOP', 'EWOFOEKOP', 'stop');

-- Dumping structure for table flight.auth_jwt
DROP TABLE IF EXISTS `auth_jwt`;
CREATE TABLE IF NOT EXISTS `auth_jwt` (
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `expiration` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `acc_token` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.auth_jwt: ~6 rows (approximately)
REPLACE INTO `auth_jwt` (`date_create`, `date_modify`, `expiration`, `id`, `user_id`, `acc_token`, `name_create`, `name_modify`) VALUES
	('2023-11-17 12:53:07.000000', '2023-11-17 12:53:07.000000', 1700207587361, 415, 414, 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJuZ29kYW5naHV5MDYxQGdtYWlsLmNvbSIsInJvbGUiOlsidXNlciJdLCJleHAiOjE3MDAyMDc1ODd9.8xWGY8a2YVhBOf5_D2R40d2oWlzc8M5fGUVmR6BNEt3g2rNtDQCbNlgphRG8bWia7N3wmBBA2x66UOWNc8yG8Q', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-17 13:02:07.000000', '2023-11-17 13:02:07.000000', 1700208127108, 427, 423, 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJkdW9uZ3RvYW50cnVuZzk0MjNAZ21haS5jb20iLCJyb2xlIjpbImNoZWNrZXIiXSwiZXhwIjoxNzAwMjA4MTI3fQ.m3TCyHHhkERxciCHusn7TAHwleI_Q_109nQqCro2ySlZ8Kg2n-AzAi1mJpE5DF_RE5MMUC6S5JMRucLnRYOeAg', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-17 14:49:39.000000', '2023-11-17 14:49:39.000000', 1700214579108, 441, 385, 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJnaWFodXlsZWx1dTIzMDZAZ21haWwuY29tIiwicm9sZSI6WyJjaGVja2VyIl0sImV4cCI6MTcwMDIxNDU3OX0.lolW1TcKHVqLxsQJi_GC4jXsxGZxkEpASnoCpHunomEOAVmd6nxcG8fvPM7_43buYzeqP4nrfRICKaxCPmVpsA', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-19 09:23:46.000000', '2023-11-19 09:23:46.000000', 1700367826047, 460, 1, 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJraG9pbmd1eWVubWluaDE4OEBnbWFpbC5jb20iLCJyb2xlIjpbImNyZWF0ZXIiXSwiZXhwIjoxNzAwMzY3ODI2fQ.i3Ty4TgW3nuNIyWdEO4qAqL0t7RN-mFq9Xn_7dm_a1rKrXttSZ0iHljbl_HynWokUWE2Ob2KGlOX-adBa1mVXg', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-19 14:21:47.000000', '2023-11-19 14:21:47.000000', 1700385707697, 503, 496, 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJraG9pbmd1eWVubWluaDE4OEBnbWFpbC5jb20iLCJyb2xlIjpbInVzZXIiXSwiZXhwIjoxNzAwMzg1NzA3fQ.Gkj3aSnPuvgYbmY_xCuG0X3RMpV6hS1tDhoSFuO_EylNsPl3IsTv8GF3i1g_wP49jReFCHQfOBMtpRgphChkHg', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-19 22:18:58.000000', '2023-11-19 22:18:58.000000', 1700414338354, 598, 527, 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJraG9pbmd1eWVubWluaDE4OEBnbWFpbC5jb20iLCJyb2xlIjpbImNyZWF0ZXIiXSwiZXhwIjoxNzAwNDE0MzM4fQ.rrGyMGCdJ8rd8drLVbbX8HrsC2eeZ2NF8cik1F9KgiCOxDuwWGe5RVXZYetW_3g6hTChsIPwI5hUkuedx-3j4Q', 'EWOFOEKOP', 'EWOFOEKOP');

-- Dumping structure for table flight.chair
DROP TABLE IF EXISTS `chair`;
CREATE TABLE IF NOT EXISTS `chair` (
  `airplane_id` bigint(20) NOT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `typechair_id` bigint(20) NOT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  `side` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `stt` varchar(255) DEFAULT NULL,
  `chair` bigint(20) DEFAULT NULL,
  `cus_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKk6lu9bl31fhkbci3xg23cq4gg` (`airplane_id`),
  KEY `FKnxd6ufb44wuo6pjl1exewlxer` (`typechair_id`),
  CONSTRAINT `FKk6lu9bl31fhkbci3xg23cq4gg` FOREIGN KEY (`airplane_id`) REFERENCES `airplane` (`id`),
  CONSTRAINT `FKnxd6ufb44wuo6pjl1exewlxer` FOREIGN KEY (`typechair_id`) REFERENCES `type_chair` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.chair: ~87 rows (approximately)
REPLACE INTO `chair` (`airplane_id`, `date_create`, `date_modify`, `id`, `typechair_id`, `name_create`, `name_modify`, `side`, `status`, `stt`, `chair`, `cus_id`) VALUES
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 94, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L260', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 95, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L261', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 97, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R263', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 98, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L270', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 99, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L271', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 100, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R272', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 101, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R273', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 102, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L280', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 103, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L281', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 104, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R282', NULL, NULL),
	(68, '2023-11-06 11:15:05.000000', '2023-11-06 11:15:05.000000', 105, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R283', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 106, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L260', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 107, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L261', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 108, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R262', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 109, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R263', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 110, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L270', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 111, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L271', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 112, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R272', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 113, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R273', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 114, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L280', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 115, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L281', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 116, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R282', NULL, NULL),
	(81, '2023-11-06 11:15:12.000000', '2023-11-06 11:15:12.000000', 117, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R283', NULL, NULL),
	(42, '2023-11-06 11:15:20.000000', '2023-11-06 11:15:20.000000', 119, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L261', NULL, NULL),
	(42, '2023-11-06 11:15:20.000000', '2023-11-06 11:15:20.000000', 120, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R262', NULL, NULL),
	(42, '2023-11-06 11:15:20.000000', '2023-11-06 11:15:20.000000', 122, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L270', NULL, NULL),
	(42, '2023-11-06 11:15:20.000000', '2023-11-06 11:15:20.000000', 123, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L271', NULL, NULL),
	(42, '2023-11-06 11:15:20.000000', '2023-11-06 11:15:20.000000', 124, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R272', NULL, NULL),
	(42, '2023-11-06 11:15:20.000000', '2023-11-06 11:15:20.000000', 125, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'full', 'R273', NULL, NULL),
	(42, '2023-11-06 11:15:21.000000', '2023-11-06 11:15:21.000000', 127, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L281', NULL, NULL),
	(42, '2023-11-06 11:15:21.000000', '2023-11-06 11:15:21.000000', 128, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R282', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 156, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L260', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 157, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L261', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 158, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L262', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 159, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L263', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 160, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L264', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 161, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R265', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 162, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R266', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 164, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R268', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 166, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L270', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 168, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L272', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 169, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L273', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 170, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L274', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 172, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R276', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 173, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R277', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 174, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R278', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 175, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R279', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 176, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L280', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 177, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L281', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 178, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L282', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 179, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L283', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 180, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L284', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 181, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R285', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 182, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R286', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 183, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R287', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 184, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R288', NULL, NULL),
	(155, '2023-11-06 17:24:13.000000', '2023-11-06 17:24:13.000000', 185, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R289', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 247, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L260', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 248, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L261', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 249, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R262', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 250, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R263', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 251, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L270', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 252, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L271', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 253, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R272', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 254, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R273', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 255, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L280', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 256, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L281', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 257, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R282', NULL, NULL),
	(246, '2023-11-11 08:10:27.000000', '2023-11-11 08:10:27.000000', 258, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R283', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 574, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L260', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 575, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L261', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 576, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L262', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 577, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R263', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 578, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R264', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 579, 26, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R265', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 580, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L270', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 581, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L271', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 582, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L272', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 583, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R273', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 584, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R274', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 585, 27, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R275', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 586, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L280', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 587, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L281', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 588, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'left', 'empty', 'L282', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 589, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R283', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 590, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R284', NULL, NULL),
	(55, '2023-11-19 20:12:05.000000', '2023-11-19 20:12:05.000000', 591, 28, 'EWOFOEKOP', 'EWOFOEKOP', 'right', 'empty', 'R285', NULL, NULL);

-- Dumping structure for table flight.customer
DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `chair_id` bigint(20) DEFAULT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `flight_id` bigint(20) NOT NULL,
  `id` bigint(20) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `ticker_id` bigint(20) NOT NULL,
  `age` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  `nationality` varchar(255) DEFAULT NULL,
  `passport` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date_use` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_s24al3jos4rs13n970p1hligm` (`chair_id`),
  KEY `FKhq9e4k4g214axl892ht3fgcrm` (`flight_id`),
  KEY `FK87um6hsjp0sow5yajcguj5lpl` (`parent_id`),
  KEY `FK9jbqrhr81vkjqymv40u4oopxe` (`ticker_id`),
  CONSTRAINT `FK87um6hsjp0sow5yajcguj5lpl` FOREIGN KEY (`parent_id`) REFERENCES `parent_bill` (`id`),
  CONSTRAINT `FK9jbqrhr81vkjqymv40u4oopxe` FOREIGN KEY (`ticker_id`) REFERENCES `ticker` (`id`),
  CONSTRAINT `FKhq9e4k4g214axl892ht3fgcrm` FOREIGN KEY (`flight_id`) REFERENCES `flight` (`id`),
  CONSTRAINT `FKkkyav9uoci7vrfufbmxnwkvgq` FOREIGN KEY (`chair_id`) REFERENCES `chair` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.customer: ~0 rows (approximately)
REPLACE INTO `customer` (`chair_id`, `date_create`, `date_modify`, `flight_id`, `id`, `parent_id`, `ticker_id`, `age`, `email`, `fullname`, `name_create`, `name_modify`, `nationality`, `passport`, `phone`, `status`, `date_use`) VALUES
	(125, '2023-11-19 20:16:07.000000', '2023-11-19 20:16:07.000000', 592, 596, 595, 593, '2003-11-20', 'khoinguyenminh188@gmail.com', 'fergergergregrer', 'EWOFOEKOP', 'EWOFOEKOP', 'albanian', 'A1234567', '0329162803', 'Hoạt động', NULL);

-- Dumping structure for table flight.fakacus
DROP TABLE IF EXISTS `fakacus`;
CREATE TABLE IF NOT EXISTS `fakacus` (
  `id` bigint(20) NOT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  `codeverify` varchar(255) DEFAULT NULL,
  `gmail` varchar(255) DEFAULT NULL,
  `verify` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.fakacus: ~0 rows (approximately)

-- Dumping structure for table flight.flight
DROP TABLE IF EXISTS `flight`;
CREATE TABLE IF NOT EXISTS `flight` (
  `airfield_id` bigint(20) NOT NULL,
  `airplane_id` bigint(20) NOT NULL,
  `date_complete` datetime(6) DEFAULT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_departure` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `location_cl_id` bigint(20) NOT NULL,
  `location_id` bigint(20) NOT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `timemove` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqg5jf1pckibt219cs283yvsh7` (`airfield_id`),
  KEY `FKb8t4272gfgo1feyyidvscbjm0` (`airplane_id`),
  KEY `FK4li3rdgudxig0xlf21n68dgwk` (`location_id`),
  KEY `FKoyvkkhc76jafokmyvxj9n3fps` (`location_cl_id`),
  CONSTRAINT `FK4li3rdgudxig0xlf21n68dgwk` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKb8t4272gfgo1feyyidvscbjm0` FOREIGN KEY (`airplane_id`) REFERENCES `airplane` (`id`),
  CONSTRAINT `FKoyvkkhc76jafokmyvxj9n3fps` FOREIGN KEY (`location_cl_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKqg5jf1pckibt219cs283yvsh7` FOREIGN KEY (`airfield_id`) REFERENCES `airfield` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.flight: ~0 rows (approximately)
REPLACE INTO `flight` (`airfield_id`, `airplane_id`, `date_complete`, `date_create`, `date_departure`, `date_modify`, `id`, `location_cl_id`, `location_id`, `name_create`, `name_modify`, `status`, `timemove`) VALUES
	(17, 42, '2023-11-22 10:12:00.000000', NULL, '2023-11-21 08:12:00.000000', '2023-11-19 20:17:44.000000', 592, 10, 11, NULL, 'EWOFOEKOP', NULL, '08 Giờ 12 phút ');

-- Dumping structure for table flight.location
DROP TABLE IF EXISTS `location`;
CREATE TABLE IF NOT EXISTS `location` (
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `name_contry` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.location: ~7 rows (approximately)
REPLACE INTO `location` (`date_create`, `date_modify`, `id`, `img`, `name`, `name_contry`, `name_create`, `name_modify`) VALUES
	(NULL, '2023-11-07 00:12:53.000000', 10, 'hochiminh.jpg', 'Hồ  Chí Minh', 'Việt Nam', NULL, 'EWOFOEKOP'),
	('2023-11-06 10:56:10.000000', '2023-11-06 10:56:10.000000', 11, 'danang.jpg', 'Đà Nẵng', 'Việt Nam', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-06 10:56:54.000000', '2023-11-06 10:56:54.000000', 12, 'dalat.jpg', 'Đà lạt', 'Việt Nam', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-06 10:59:05.000000', '2023-11-06 10:59:05.000000', 13, 'tokyo.jpg', 'Tokyo', 'Nhật bản', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-06 10:59:32.000000', '2023-11-06 10:59:32.000000', 14, 'newyork.jpg', 'Newyork', 'Mỹ', 'EWOFOEKOP', 'EWOFOEKOP'),
	(NULL, '2023-11-18 22:10:21.000000', 15, 'india.jpg', 'Ấn độ', 'Ấn độ', NULL, 'EWOFOEKOP');

-- Dumping structure for table flight.parent_bill
DROP TABLE IF EXISTS `parent_bill`;
CREATE TABLE IF NOT EXISTS `parent_bill` (
  `sumprice` int(11) DEFAULT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `iduser` bigint(20) DEFAULT NULL,
  `codepay` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.parent_bill: ~0 rows (approximately)
REPLACE INTO `parent_bill` (`sumprice`, `date_create`, `date_modify`, `id`, `iduser`, `codepay`, `name_create`, `name_modify`, `status`) VALUES
	(1100000, '2023-11-19 20:16:07.000000', '2023-11-19 20:16:07.000000', 595, 527, '77088364', 'EWOFOEKOP', 'EWOFOEKOP', 'yes');

-- Dumping structure for table flight.role
DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.role: ~3 rows (approximately)
REPLACE INTO `role` (`date_create`, `date_modify`, `id`, `name`, `name_create`, `name_modify`) VALUES
	('2023-11-06 10:17:17.000000', '2023-11-06 10:17:18.000000', 1, 'user', NULL, NULL),
	('2023-11-06 10:17:19.000000', '2023-11-06 10:17:18.000000', 2, 'creater', NULL, NULL),
	('2023-11-06 10:17:20.000000', '2023-11-06 10:17:20.000000', 3, 'checker', NULL, NULL);

-- Dumping structure for table flight.squences
DROP TABLE IF EXISTS `squences`;
CREATE TABLE IF NOT EXISTS `squences` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.squences: ~1 rows (approximately)
REPLACE INTO `squences` (`next_val`) VALUES
	(599);

-- Dumping structure for table flight.ticker
DROP TABLE IF EXISTS `ticker`;
CREATE TABLE IF NOT EXISTS `ticker` (
  `buy` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `price_sale` int(11) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `flight_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_7dx9q7llqy4qxywv773v0da39` (`flight_id`),
  CONSTRAINT `FK4gjww131qraoe3j0gu50o4pyd` FOREIGN KEY (`flight_id`) REFERENCES `flight` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.ticker: ~0 rows (approximately)
REPLACE INTO `ticker` (`buy`, `price`, `price_sale`, `quality`, `status`, `date_create`, `date_modify`, `flight_id`, `id`, `name_create`, `name_modify`) VALUES
	(1, 1000000, 0, 12, 0, NULL, '2023-11-19 20:17:45.000000', 592, 593, NULL, 'EWOFOEKOP');

-- Dumping structure for table flight.trademark
DROP TABLE IF EXISTS `trademark`;
CREATE TABLE IF NOT EXISTS `trademark` (
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.trademark: ~5 rows (approximately)
REPLACE INTO `trademark` (`date_create`, `date_modify`, `id`, `img`, `name`, `name_create`, `name_modify`) VALUES
	('2023-11-06 11:19:40.000000', '2023-11-06 11:18:44.000000', 20, 'viettravel.png', 'Travel', NULL, 'EWOFOEKOP'),
	('2023-11-06 11:11:16.000000', '2023-11-06 11:11:16.000000', 21, 'bambo.png', 'Bambo', 'EWOFOEKOP', 'EWOFOEKOP'),
	(NULL, '2023-11-06 11:20:03.000000', 22, 'scoot.png', 'Scoot', NULL, 'EWOFOEKOP'),
	('2023-11-06 11:11:45.000000', '2023-11-06 11:11:45.000000', 23, 'thailyon.png', 'Thai', 'EWOFOEKOP', 'EWOFOEKOP'),
	('2023-11-06 11:11:53.000000', '2023-11-06 11:11:53.000000', 24, 'jal.png', 'Jal', 'EWOFOEKOP', 'EWOFOEKOP');

-- Dumping structure for table flight.type_chair
DROP TABLE IF EXISTS `type_chair`;
CREATE TABLE IF NOT EXISTS `type_chair` (
  `luggage` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.type_chair: ~3 rows (approximately)
REPLACE INTO `type_chair` (`luggage`, `price`, `date_create`, `date_modify`, `id`, `name`, `name_create`, `name_modify`) VALUES
	(4, 0, '2023-11-06 11:12:55.000000', '2023-11-06 11:12:55.000000', 26, 'Phổ thông', 'EWOFOEKOP', 'EWOFOEKOP'),
	(7, 100000, '2023-11-06 11:13:12.000000', '2023-11-06 11:13:12.000000', 27, 'Đặt biệt', 'EWOFOEKOP', 'EWOFOEKOP'),
	(10, 50000, '2023-11-06 11:13:25.000000', '2023-11-06 11:13:25.000000', 28, 'Thương gia', 'EWOFOEKOP', 'EWOFOEKOP');

-- Dumping structure for table flight.user
DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `date_create` datetime(6) DEFAULT NULL,
  `date_modify` datetime(6) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `name_create` varchar(255) DEFAULT NULL,
  `name_modify` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `codeverify` varchar(255) DEFAULT NULL,
  `verify` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.user: ~7 rows (approximately)
REPLACE INTO `user` (`date_create`, `date_modify`, `id`, `email`, `fullname`, `name_create`, `name_modify`, `password`, `phone`, `codeverify`, `verify`) VALUES
	('2023-11-06 10:17:58.000000', '2023-11-06 10:17:58.000000', 1, 'khoinguyenminh181@gmail.com', 'Nguyễn Minh Khôi', 'EWOFOEKOP', 'EWOFOEKOP', '$2a$10$5ORB7zmY7T5LptTuLmSs5.mz4WZF01RpghPRpjfgj3.M1Q2V53J4e', '0329162803', NULL, NULL),
	('2023-11-10 13:07:32.000000', '2023-11-10 13:07:32.000000', 225, 'storesave9090@gmail.com', 'Lam Lam', 'EWOFOEKOP', 'EWOFOEKOP', '$2a$10$K9qnmhZhcaMgTqbaLWnGO.bNNInQP6cKRzWh9.3yU.yAOb077iM4q', '0329162803', NULL, NULL),
	('2023-11-11 08:06:24.000000', '2023-11-11 08:06:24.000000', 236, 'MinhHoa188@gmail.com', 'Minh Hoa', 'EWOFOEKOP', 'EWOFOEKOP', '$2a$10$Jzfhs/0AH3r.4gzFXQ.g1et3geaNUMlk.3G/jM0d5ICzRyOD5yBdi', '0329162803', NULL, NULL),
	('2023-11-16 15:53:38.000000', '2023-11-16 15:53:38.000000', 385, 'giahuyleluu2306@gmail.com', 'huygia', 'EWOFOEKOP', 'EWOFOEKOP', '$2a$10$eiwATXxZgx1q1fWsl/B0qOTeEdGWnh17EA4X/HFfe9TGBaZLgqW2S', '0979575147', NULL, NULL),
	('2023-11-17 12:52:59.000000', '2023-11-17 12:52:59.000000', 414, 'ngodanghuy061@gmail.com', 'Ngo Dang Huy', 'EWOFOEKOP', 'EWOFOEKOP', '$2a$10$CRUJLr2a0gxoqqbZeoUQ1.toTbasGVYd09ivHlxbL1S81HKPP9Bpi', '1234567894', NULL, NULL),
	('2023-11-17 12:59:00.000000', '2023-11-17 12:59:00.000000', 423, 'duongtoantrung9423@gmai.com', 'trung', 'EWOFOEKOP', 'EWOFOEKOP', '$2a$10$4/y/RjJkxhtGqDs6Ia2xZO7iSuBaGsXPNG3POGWAVthL1rQcbfjxC', '0928862227', NULL, NULL),
	('2023-11-19 12:53:56.000000', '2023-11-19 12:53:56.000000', 496, 'khoinguyenminh183@gmail.com', 'ewfewfe', 'EWOFOEKOP', 'EWOFOEKOP', '$2a$10$7zalhHayrXvEo2EGMe4or.ikVyfoFlHBc8zSty7X8HeIgD8FxdGJG', '0329162803', '$2a$10$q2j1Mhv2SLI.9pIekK5rQecUDX8DmujlvtS7EvYib6PFcnul8W1zO', b'1'),
	('2023-11-19 17:51:37.000000', '2023-11-19 17:51:37.000000', 527, 'khoinguyenminh188@gmail.com', 'Nguyễn Minh Koi', 'EWOFOEKOP', 'EWOFOEKOP', '$2a$10$c31GyNngZP9/D3R9j9z8oeoVBD50PUaZCvyVZRl9HraET9dhkEHa6', '0329162803', '$2a$10$jI5AxgtaeoJzdPqQ3wFyxeGA7BH.kVIaOgh2UTusQraZ0GPq2r9eC', b'1');

-- Dumping structure for table flight.users_roles
DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE IF NOT EXISTS `users_roles` (
  `role_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`role_id`,`user_id`),
  KEY `FKgd3iendaoyh04b95ykqise6qh` (`user_id`),
  CONSTRAINT `FKgd3iendaoyh04b95ykqise6qh` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKt4v0rrweyk393bdgt107vdx0x` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table flight.users_roles: ~8 rows (approximately)
REPLACE INTO `users_roles` (`role_id`, `user_id`) VALUES
	(3, 1),
	(3, 225),
	(3, 236),
	(3, 385),
	(3, 414),
	(3, 423),
	(3, 496),
	(3, 527);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
