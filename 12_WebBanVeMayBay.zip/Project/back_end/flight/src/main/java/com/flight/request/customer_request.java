package com.flight.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class customer_request {

	private  Long id;
	private String nationality;
	private String passport;
	private String email;
	private String fullname;
	private String age;
	private String statuspayment;
	private Long idtick;
	private String tel;
	private Long seat;
	private String status;
	
}
