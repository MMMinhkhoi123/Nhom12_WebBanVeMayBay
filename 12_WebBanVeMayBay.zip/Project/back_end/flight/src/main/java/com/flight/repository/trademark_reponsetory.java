package com.flight.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight.entity.trademark;

public interface trademark_reponsetory extends JpaRepository<trademark, Long> {

}
