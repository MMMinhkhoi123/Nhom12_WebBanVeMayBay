package com.flight.reponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class email_reponse {
	private String title;
	private String trademark;
	private String location_go;
	private String location_fish;
	private String time;
	private String airfield;
	private String seat;
	private String codeflight;
	private String kilo;
	private String price_ticker;
	private String price_chair;
}
