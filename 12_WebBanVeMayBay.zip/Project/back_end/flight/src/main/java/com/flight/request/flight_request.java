package com.flight.request;

import lombok.Data;

@Data
public class flight_request {

	private Long date_departure;
	private Long date_complete;
	private Long id;
	private Long id_airfield;
	private Long id_airplane;
	private Long id_location_complete;
	private Long id_location_departure;
	private int price;
	private String timemove;
	private String status;
	
	private int sale;
	private Long idtick;
}
