package com.flight.service;

import com.flight.reponse.payment_reponse;

public interface I_payment {
	
	public payment_reponse urlpay(int sum);

}
