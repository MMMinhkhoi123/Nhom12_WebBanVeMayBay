package com.flight.reponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class pass_reponse {
	private String mess;
	private String token;
	private boolean status;
	
}
