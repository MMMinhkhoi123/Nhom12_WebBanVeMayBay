package com.flight.reponse;

public class type_chair_reponse extends common_mess_status {

}
