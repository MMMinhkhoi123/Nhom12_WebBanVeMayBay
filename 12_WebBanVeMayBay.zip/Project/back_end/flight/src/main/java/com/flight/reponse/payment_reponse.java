package com.flight.reponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class payment_reponse {

	private String codebill;
	private String url;
}
