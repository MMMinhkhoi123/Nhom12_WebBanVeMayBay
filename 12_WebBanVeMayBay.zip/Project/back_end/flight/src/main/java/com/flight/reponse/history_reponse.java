package com.flight.reponse;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class history_reponse {
	private String imgtrademark;
	private String nametrademark;
	private Long trademark;
	private int price;
	private String locationgo;
	private String locationfish;
	private Long timemua;
	private Long timego;
	private Long timefish;
	private String status;
	private Long id;
	private Long date_use;
}
