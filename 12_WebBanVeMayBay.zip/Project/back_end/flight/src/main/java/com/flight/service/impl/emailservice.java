package com.flight.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.flight.reponse.email_reponse;
import com.flight.reponse.email_reponsev2;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;


@Service
public class emailservice {

	@Autowired
	private JavaMailSender mailsender;
	
	@Autowired
	private TemplateEngine tyEngine;
	public void sendEmail(String to, String subject, String body) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        mailsender.send(message);
        System.out.print("Minh Khoi");
    }
	
	public void sendEmailverify(String to, String subject, String codeverify, int type) {
		   Context ctx = new Context();
	        ctx.setVariable("codeverify", codeverify);
	        ctx.setVariable("role", type);
	        MimeMessage mess = mailsender.createMimeMessage();
	        try {      	
				MimeMessageHelper hepler = new MimeMessageHelper(mess, false, "UTF-8");	
				hepler.setTo(to);
				hepler.setSubject(subject);
				hepler.setText("Verify email now", false);
		        String htmlContent = tyEngine.process("Verify", ctx);
		        mess.setContent(htmlContent, "text/html; charset=utf-8");
		        hepler.setText(htmlContent, true); // true = isHtml
				mailsender.send(mess);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
	        
    }
	
	public void sendEmailtest(String to, String subject) {
		 Context ctx = new Context();
	        MimeMessage mess = mailsender.createMimeMessage();
	        try {      	
				MimeMessageHelper hepler = new MimeMessageHelper(mess, false, "UTF-8");	
				hepler.setTo(to);
				hepler.setSubject(subject);
				hepler.setText("Test teamplate", false);
		        String htmlContent = tyEngine.process("delay_v2", ctx);
		        mess.setContent(htmlContent, "text/html; charset=utf-8");
		        hepler.setText(htmlContent, true); // true = isHtml
				mailsender.send(mess);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
    }
	
	
	public void sendEmail_destroy(String to, String subject,
		String name, String location,String location_end,String lugage, String pricechair, String prictick, String codeflight, String date) {
        Context ctx = new Context();
        ctx.setVariable("name", name);
        ctx.setVariable("codeflight", codeflight);
        ctx.setVariable("kilo", lugage);
        ctx.setVariable("location_departure", location);
        ctx.setVariable("location_complete", location_end);
        ctx.setVariable("datedetroy", date );
        ctx.setVariable("price_chair", pricechair);
        ctx.setVariable("price_tick", prictick);
        ;
        MimeMessage mess = mailsender.createMimeMessage();
        try {      	
			MimeMessageHelper hepler = new MimeMessageHelper(mess, false, "UTF-8");	
			hepler.setTo(to);
			hepler.setSubject(subject);
			hepler.setText("Destroy einvoice", false);
	        String htmlContent = tyEngine.process("delay_v2", ctx);
	        mess.setContent(htmlContent, "text/html; charset=utf-8");
	        hepler.setText(htmlContent, true); // true = isHtml
			mailsender.send(mess);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
        
    }
	
	public void send_delay(String [] to, String subject, String location, String locationed,
			String Codeflight, String time) {
	        Context ctx = new Context();
	        ctx.setVariable("location_departure", location);
	        ctx.setVariable("location_complete", locationed);
	        ctx.setVariable("codeflight", Codeflight);
	        ctx.setVariable("datedetroy", time);
	        MimeMessage mess = mailsender.createMimeMessage();
	        try {      	
				MimeMessageHelper hepler = new MimeMessageHelper(mess, false, "UTF-8");	
				hepler.setTo(to);
				hepler.setSubject(subject);
				hepler.setText("Delay flight", false);
		        String htmlContent = tyEngine.process("delay_v3", ctx);
		        mess.setContent(htmlContent, "text/html; charset=utf-8");
		        hepler.setText(htmlContent, true); // true = isHtml
				mailsender.send(mess);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
	        
	    }
	
	public void sendEmail_html(String to, String subject, email_reponsev2 array) {
        Context ctx = new Context();
        ctx.setVariable("code",  array.getCode());
        ctx.setVariable("sumprice", array.getSumprice());
        ctx.setVariable("codepay", array.getCodepay());
        ctx.setVariable("list", array.getList());
        ctx.setVariable("names", array.getNamedata());
        ctx.setVariable("datebuy", array.getDateby());
        MimeMessage mess = mailsender.createMimeMessage();
        try {
        	
			MimeMessageHelper hepler = new MimeMessageHelper(mess, false, "UTF-8");
			
			hepler.setTo(to);
			hepler.setSubject(subject);
			hepler.setText("Helo cac ban", false);

	        String htmlContent = tyEngine.process("testabc", ctx);
	        
	        htmlContent.replace("${foo}","minhkhoi" );
	        mess.setContent(htmlContent, "text/html; charset=utf-8");
	        hepler.setText(htmlContent, true); // true = isHtml
			mailsender.send(mess);
			
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
	
}
