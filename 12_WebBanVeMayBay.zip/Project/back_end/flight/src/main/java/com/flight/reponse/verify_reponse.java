package com.flight.reponse;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class verify_reponse {
	 private String token;
	
}
