package com.flight.reponse;

public class airplane_reponse extends common_mess_status{
}
