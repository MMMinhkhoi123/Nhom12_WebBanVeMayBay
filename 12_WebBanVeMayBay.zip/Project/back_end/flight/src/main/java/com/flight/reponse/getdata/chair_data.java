package com.flight.reponse.getdata;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class chair_data {
	private String side;
	private String status;
	private String stt;
	private Long id;
	private Long typechair;
}
