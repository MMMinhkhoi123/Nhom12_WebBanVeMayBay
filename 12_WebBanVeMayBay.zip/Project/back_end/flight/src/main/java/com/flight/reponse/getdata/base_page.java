package com.flight.reponse.getdata;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class base_page {
	public int toltalpage;
	public int page;
}
