package com.flight.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.flight.entity.fakacus;
import com.flight.reponse.register_reponse;
import com.flight.repository.jakecus_repo;
import com.flight.service.I_fakecus;

@Service
public class fakecus_service implements I_fakecus {

	@Autowired
	jakecus_repo cusfake;
	
	private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	
	
	@Autowired
	emailservice emailservice;
	
	@Override
	public String save(String gmail) {
		fakacus data = new fakacus();
		if (cusfake.findonebynemail(gmail).isPresent()) {
			emailservice.sendEmailverify(gmail,"Verify email", data.getCodeverify(), 1);
		} else {
		data.setCodeverify( passwordEncoder.encode(gmail + "abcc"));
		data.setVerify(false);
		data.setGmail(gmail);
		cusfake.save(data);
		emailservice.sendEmailverify(gmail,"Verify email", data.getCodeverify(), 1);
		}
		return gmail;
	}

	@Override
	public void setversity(String code) {
		fakacus data = cusfake.findonebycodeverify(code).get();
		System.out.print(data);
		cusfake.update_status(data.getGmail());
	}

	@Override
	public ResponseEntity<register_reponse> getstatus(String gmail) {
		fakacus data = cusfake.findonebynemail(gmail).get();
		register_reponse reponse = new register_reponse();
		if(data.isVerify() == true) {
			reponse.setMess("đã xác thực");
			reponse.setStatus(8);
			cusfake.deleteById(data.getId());
			return new ResponseEntity<>(reponse, HttpStatus.OK);
		} else {
			reponse.setMess("chưa xác thực");
			reponse.setStatus(9);
			return new ResponseEntity<>(reponse, HttpStatus.BAD_REQUEST);
		}
	}

}
