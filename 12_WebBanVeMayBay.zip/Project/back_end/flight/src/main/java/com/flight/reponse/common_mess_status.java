package com.flight.reponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class common_mess_status {
	private String mess;
	private int status;
}
