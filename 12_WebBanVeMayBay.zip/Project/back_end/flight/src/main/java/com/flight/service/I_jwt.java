package com.flight.service;

import com.flight.entity.user;

public interface I_jwt {
  public void save(String jsontoken, user user);
}
