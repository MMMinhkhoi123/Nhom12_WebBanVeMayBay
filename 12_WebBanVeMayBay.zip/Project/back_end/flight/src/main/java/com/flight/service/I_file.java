package com.flight.service;

import java.io.InputStream;

public interface I_file {

	public InputStream getresoure(String path, String filename);
}
