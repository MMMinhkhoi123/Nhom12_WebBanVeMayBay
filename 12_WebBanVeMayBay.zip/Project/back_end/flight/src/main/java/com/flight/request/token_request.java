package com.flight.request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class token_request {
	private String token;
}
