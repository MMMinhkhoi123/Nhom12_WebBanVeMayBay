package com.flight.reponse.getdata;

import com.flight.request.type_chair_request;

public class typechair_data extends type_chair_request{

}
