package com.flight.request;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class pass_request {
	private String token;
	private String passold;
	private String passnew;
}
