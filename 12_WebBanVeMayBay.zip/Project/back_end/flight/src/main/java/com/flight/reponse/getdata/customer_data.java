package com.flight.reponse.getdata;

import java.util.List;

import com.flight.reponse.customer_reponses;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class customer_data extends base_page {

	List<customer_reponses> list;
}
