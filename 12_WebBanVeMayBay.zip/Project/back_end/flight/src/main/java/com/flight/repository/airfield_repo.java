package com.flight.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight.entity.airfield;

public interface airfield_repo extends JpaRepository<airfield, Long> {

}
