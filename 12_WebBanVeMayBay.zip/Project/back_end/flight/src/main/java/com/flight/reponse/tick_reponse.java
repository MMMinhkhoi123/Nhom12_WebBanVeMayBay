package com.flight.reponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class tick_reponse {
	private Long idtick;
	private int price;
}
