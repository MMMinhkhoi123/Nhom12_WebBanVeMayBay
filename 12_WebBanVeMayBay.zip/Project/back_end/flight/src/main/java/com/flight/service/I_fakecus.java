package com.flight.service;

import org.springframework.http.ResponseEntity;

import com.flight.reponse.register_reponse;

public interface I_fakecus {

	public String save(String gmail);
	public void setversity(String code);
	public ResponseEntity<register_reponse> getstatus(String gmail);
}
