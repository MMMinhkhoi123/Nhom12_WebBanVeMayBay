package com.flight.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class einvoice_request {
	private Long idbill;
	private String token;
}
