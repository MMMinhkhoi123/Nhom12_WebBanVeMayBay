package com.flight.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.flight.entity.fakacus;
import com.flight.entity.user;

import jakarta.transaction.Transactional;

public interface jakecus_repo extends JpaRepository<fakacus, Long>{

	
	@Query(value = "select * from fakacus where gmail = :ems", nativeQuery = true)
	Optional<fakacus> findonebynemail(@Param(value = "ems")String email);
	
	@Query(value = "select * from fakacus where codeverify = :codeverify", nativeQuery = true)
	Optional<fakacus> findonebycodeverify(@Param(value = "codeverify")String email);
	
	@Modifying
	@Transactional
	@Query(value = "update fakacus set verify = true where gmail = :emails ", nativeQuery = true)
	public void update_status(@Param(value = "emails") String email);
}
