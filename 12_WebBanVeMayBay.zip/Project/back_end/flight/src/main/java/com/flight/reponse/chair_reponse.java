package com.flight.reponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class chair_reponse {

	private Long idchair;
	private String stt;
	private String nametype;
	private int price;

}
