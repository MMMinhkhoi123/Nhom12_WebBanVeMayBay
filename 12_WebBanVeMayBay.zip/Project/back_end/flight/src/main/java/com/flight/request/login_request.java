package com.flight.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class login_request {

	private String email;
	private String password;
	
}
