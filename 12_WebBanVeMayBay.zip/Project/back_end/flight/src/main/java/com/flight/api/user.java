package com.flight.api;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.flight.reponse.customer_reponse;
import com.flight.reponse.history_reponse;
import com.flight.request.customer_request;
import com.flight.request.email_request;
import com.flight.service.impl.customer_service;
import com.flight.service.impl.emailservice;
import com.flight.service.impl.parent_service;
import com.flight.service.impl.ticker_service;
import com.flight.service.impl.user_service;



@RestController
@RequestMapping("/user")
@CrossOrigin
public class user {
	@Autowired
	customer_service sustomerservice;
	
	@Autowired
	emailservice emailservice;
	
	@Autowired
	parent_service parent_service;
	
	@Autowired
	user_service userservice;
	
	@Autowired
	ticker_service tickerservice;
	
	@PostMapping("/info")
	public ResponseEntity<customer_reponse> create(@RequestBody Optional<List<customer_request>> request) {
		return sustomerservice.save(request.get());
	}
	
	@GetMapping("/history")
	public ResponseEntity<List<history_reponse>> gethistory(@RequestParam("token") Optional<String> token) {
	return userservice.gethistory(token.get());
	}
	
	@GetMapping("/ticker-destroy")
	public void requid_destroy(@RequestParam("id") Optional<Long> idcustomer,@RequestParam("date") Optional<Long> Date) {
		sustomerservice.requid_destroy(idcustomer.get(), Date.get());
	}
	
	@GetMapping("/ticker-restore/{id}")
	public void requid_restore(@PathVariable("id") Optional<Long> idcustomer) {
		sustomerservice.requid_restore(idcustomer.get());
	}
	
	
	@PostMapping("/email")
	public String sendmail(@RequestBody Optional<email_request> data) {
		return "send mail success";
	}
	
	@GetMapping("/test_url")
	public String sendmail() {
		// Get Current Directory using getAbsolutePath()
        File file = new File("");
        String currentDirectory = file.getAbsolutePath();
        File data = new File( currentDirectory);
        System.out.println("Current working directory : " + data.pathSeparatorChar);
		return "Minhkhoi";
	}
	
	
}
