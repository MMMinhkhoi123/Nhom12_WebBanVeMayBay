package com.flight.reponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class customer_reponse {

	private Long idbill;
	private String mess;
	private String url;
	private int price;
	
}
