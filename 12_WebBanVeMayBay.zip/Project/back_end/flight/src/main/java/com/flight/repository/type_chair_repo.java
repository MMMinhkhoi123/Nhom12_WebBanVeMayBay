package com.flight.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight.entity.type_chair;

public interface type_chair_repo extends JpaRepository<type_chair, Long> {

}
