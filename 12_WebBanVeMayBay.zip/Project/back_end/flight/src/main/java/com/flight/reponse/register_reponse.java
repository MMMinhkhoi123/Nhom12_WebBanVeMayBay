package com.flight.reponse;

public class register_reponse extends common_mess_status {
}
