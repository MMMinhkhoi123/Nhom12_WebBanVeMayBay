package com.flight.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.flight.entity.auth_jwt;
import com.flight.entity.user;

import jakarta.transaction.Transactional;

public interface jwt_repo extends JpaRepository<auth_jwt, Long> {
	

	@Query(value = "select * from auth_jwt where user_id = :id", nativeQuery = true)
	Optional<auth_jwt> findoneuser(@Param(value = "id")Long id);
	
}
