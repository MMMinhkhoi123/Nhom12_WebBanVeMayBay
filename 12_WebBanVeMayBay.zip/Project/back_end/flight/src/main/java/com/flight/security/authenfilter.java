package com.flight.security;

import java.io.IOException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.flight.entity.auth_jwt;
import com.flight.entity.user;
import com.flight.repository.jwt_repo;
import com.flight.repository.user_repo;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class authenfilter  extends OncePerRequestFilter{

	
	@Autowired
	private GeneredJWT jwtGenerator;
	
	@Autowired
	private config_userdetail_service userdetail_service;
	
	@Autowired
	private jwt_repo jwtrJwt_repo;
	
	@Autowired
	private user_repo user_repo;
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String token = getJWTFromRequest(request);
		
		 if(StringUtils.hasText(token) && jwtGenerator.validateToken(token)) {        	
       	  
	            String username = jwtGenerator.getUsernameFromJWT(token);
	            
	            UserDetails userDetails = userdetail_service.loadUserByUsername(username);
	            
	            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null,
	                    userDetails.getAuthorities());
	            authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
	            SecurityContextHolder.getContext().setAuthentication(authenticationToken);	            
	        } else {
	        	// lấy ra user để kiềm tra db
	        	if (StringUtils.hasText(token)) {
	        	String username = jwtGenerator.getUsernameFromJWT(token);
	        	 user user = user_repo.findonebynemail(username).get();
	        	 auth_jwt jwt_store = jwtrJwt_repo.findoneuser(user.getId()).get();
	        	 if(jwt_store.getExpiration() >= new Date().getTime()) {
	        		   UserDetails userDetails = userdetail_service.loadUserByUsername(username);
	   	            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null,
	   	                    userDetails.getAuthorities());
	   	            authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
	   	            SecurityContextHolder.getContext().setAuthentication(authenticationToken);	  
	        	 }
	        	}
	        }
	    filterChain.doFilter(request, response);
	}
	private String getJWTFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");  
        if(StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        return null;
    }

}
