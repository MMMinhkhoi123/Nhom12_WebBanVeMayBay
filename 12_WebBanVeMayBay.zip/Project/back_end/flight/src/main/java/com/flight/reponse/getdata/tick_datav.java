package com.flight.reponse.getdata;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class tick_datav extends base_page {
    private	List<ticker_data> list ;
}
