package com.flight.reponse;

public class flight_reponse extends common_mess_status {

}
