package com.flight.security;

public class Time_contranst {

	public static final long time_Token = 30*60*1000;
	public static final long time_refeash_Token = 2*60*60*1000;
}
