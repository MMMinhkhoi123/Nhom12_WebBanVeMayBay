package com.flight.reponse.getdata;

import java.util.List;


import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class airplane_datav extends base_page{
	private List<airplane_date> list;	
}
