package com.flight.reponse;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class trademark_reponse{
	private String mess;
	private int status;
}
