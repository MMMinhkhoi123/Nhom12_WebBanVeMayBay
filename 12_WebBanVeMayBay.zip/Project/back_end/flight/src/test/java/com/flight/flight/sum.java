package com.flight.flight;

import lombok.Data;

@Data
public class sum {
	private int a;
	private int b;
}
