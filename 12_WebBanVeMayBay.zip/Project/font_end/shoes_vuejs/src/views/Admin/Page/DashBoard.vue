<template>
  <h1>This is Dashboard</h1>
</template>
<script>
export default {
  setup() {},
};
</script>
<style scoped>
.container {
  height: 100vh;
  background: rgb(61, 59, 59);
  padding-left: 300px;
}
.content {
  background: rgb(117, 117, 230);
  padding: 40px;
  position: relative;
}
.select {
  display: flex;
  gap: 10px;
}
.select > div {
  padding: 20px 40px;
  background: white;
  border-radius: 10px;
  display: flex;
  gap: 10px;
}
</style>
