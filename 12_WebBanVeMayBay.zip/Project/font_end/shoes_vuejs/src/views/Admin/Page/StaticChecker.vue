<template>
  <div class="parent">
    <div
      v-if="
        $store.state.md_tick.tick.list && $store.state.md_customer.customer.list
      "
      class="count"
    >
      <span>Số Lượng</span>
      <div class="count_tick">
        <div class="child">
          <div>
            <font-awesome-icon class="icon" :icon="['fas', 'ticket']" />
            {{ $store.state.list.tick.length }}
          </div>
        </div>
      </div>
      <div class="count_customer">
        <div>
          <font-awesome-icon :icon="['fas', 'users-between-lines']" />
          {{ $store.state.md_customer.customer.list.length }}
        </div>
      </div>
      <div class="count_bill">
        <div class="child">
          <div>
            <font-awesome-icon :icon="['fas', 'credit-card']" />
            {{ $store.state.md_bill.bills_all.length }}
          </div>
        </div>
      </div>
    </div>
    <div v-if="$store.state.md_bill.bills" class="action">
      <span
        >Thanh Toán
        <font-awesome-icon :icon="['fas', 'credit-card']" />
      </span>
      <div class="count">
        <span>Chờ</span>
        <div class="wait">
          <div>
            <font-awesome-icon :icon="['fas', 'users-between-lines']" />{{
              $store.getters["md_bill/bills_status"]("no").length
            }}
          </div>
        </div>
      </div>
      <div class="count">
        <span>Hoàn thành</span>
        <div class="done">
          <div>
            <font-awesome-icon :icon="['fas', 'users-between-lines']" />{{
              $store.getters["md_bill/bills_status"]("yes").length
            }}
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="fill">
    <h1 class="tts">Thống kê vé</h1>
    <div class="filter">
      <label
        @click="(status_filter = 1), call()"
        :class="status_filter == 1 ? 'hilight' : null"
        >Hôm nay</label
      >
      <label
        @click="(status_filter = 2), call()"
        :class="status_filter == 2 ? 'hilight' : null"
        >Tháng này</label
      >
      <label
        @click="(status_filter = 3), call()"
        :class="status_filter == 3 ? 'hilight' : null"
        >Năm này</label
      >
      <div class="fill_date">
        <input v-model="data.date_start" type="date" />
        <input v-model="data.date_end" type="date" />
        <button @click="call()">
          <font-awesome-icon :icon="['fas', 'filter']" />
        </button>
      </div>
    </div>
    <div class="money">
      <span v-if="status_filter">
        <strong>
          {{
            status_filter == 1
              ? "Hôm nay"
              : status_filter == 2
              ? "Tháng này"
              : "Năm này"
          }}</strong
        >
        {{ sum }} vnd
        <font-awesome-icon
          class="icon"
          :icon="['fas', 'filter-circle-dollar']"
        />
      </span>
    </div>

    <div v-if="$store.state.md_trademark.trademark_all" class="static">
      <div v-if="datas" id="my-chart" class="pie">
        <table class="charts-css line show-labels show-heading show-data-axes">
          <caption class="titlte">
            Chi Tiết tiền
          </caption>
          <tbody>
            <tr v-for="item in data_dest" :key="item">
              <th scope="row">{{ item.name }}</th>
              <td :style="'--start : 0 ;  --end : ' + item.price / sum">
                <span class="data"> {{ format(item.price) }}</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div id="my-chart">
        <table
          class="charts-css column show-heading show-labels show-5-secondary-axes data-spacing-10"
        >
          <caption class="titlte">
            Vé bán
            <font-awesome-icon class="icon" :icon="['fas', 'ticket']" />
          </caption>
          <thead>
            <tr>
              <th scope="col">Hãng bay</th>
              <th scope="col">Số lượng bán ra</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in datas == null
                ? $store.state.md_trademark.trademark_all
                : datas"
              :key="item"
            >
              <th>
                <img
                  width="30"
                  height="30"
                  :src="
                    'http://localhost:8081/img/trademark/' +
                    item.id +
                    '&3&' +
                    item.img
                  "
                />
              </th>
              <td :style="{ '--size': item.count / 100 }">
                {{ item.count == 0 ? "" : item.count }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="$store.state.md_trademark.trademark_all" id="my-chart">
        <table
          class="charts-css column show-heading show-labels show-5-secondary-axes data-spacing-10"
        >
          <caption class="titlte">
            Vé Đã bán được
            <font-awesome-icon class="icon" :icon="['fas', 'ticket']" />
          </caption>
          <thead>
            <tr>
              <th scope="col">Hãng bay</th>
              <th scope="col">Số lượng bán ra</th>
            </tr>
          </thead>
          <tbody>
            <tr
              class="ht"
              v-for="item in datas == null
                ? $store.state.md_trademark.trademark_all
                : datas"
              :key="item"
            >
              <th class="colum">
                <img
                  width="30"
                  height="30"
                  :src="
                    'http://localhost:8081/img/trademark/' +
                    item.id +
                    '&3&' +
                    item.img
                  "
                />
              </th>
              <td class="data2" :style="{ '--size': item.buy / 100 }">
                {{ item.buy == 0 ? "" : item.buy }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
<script>
import store from "@/store";
import { computed, reactive, ref } from "vue";
// import store from "@/store";
export default {
  setup() {
    store.dispatch("md_customer/get_customer");
    store.dispatch("md_tick/get_tick");
    store.dispatch("md_bill/get_bill_all");
    store.dispatch("list/get_tickx");

    store.dispatch("md_trademark/set_all_trademarks");

    const status_filter = ref(0);
    const data = reactive({
      status: status_filter.value,
      date_start: 0,
      date_end: 0,
    });
    const datas = computed(() => {
      return store.state.md_trademark.trademark_static;
    });

    const call = () => {
      data.status = status_filter.value;
      data.date_start = new Date(data.date_start).getTime();
      data.date_end = new Date(data.date_end).getTime();
      store.dispatch("md_trademark/set_trademarks_static", data);
    };

    const sum = computed(() => {
      var sum = 0;
      for (var item in datas.value) {
        sum += datas.value[item].price;
      }
      return sum;
    });

    const VND = new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    });

    const format = (value) => {
      return VND.format(value);
    };

    const data_dest = computed(() => {
      console.log(datas.value.filter((e) => e.price > 0));
      return datas.value.filter((e) => e.price > 0);
    });
    const check_sum = (value) => {
      return value / sum.value;
    };
    return {
      status_filter,
      data,
      call,
      datas,
      sum,
      check_sum,
      data_dest,
      format,
    };
  },
};
</script>
<style scoped>
.titlte {
  font-size: 20px;
}
.tts {
  color: white;
}
.data {
  font-size: 20px;
  margin-right: 50px;
}
.money {
  padding: 10px;
  margin-left: 20px;
  display: flex;
}
.money > span > strong {
  color: green;
  font-size: 20px;
}
.money > span > .icon {
  font-size: 40px;
  color: greenyellow;
}
.money > span {
  font-size: 20px;
  display: block;
  padding: 40px;
  background: rgb(209, 233, 209);
  border-radius: 20px;
  border: 3px solid rgb(71, 211, 71);
}
.fill_date {
  display: flex;
  gap: 10px;
}
.fill_date > input {
  border-radius: 5px;
}
.fill_date > button {
  padding: 0 20px;
  background: #1823f3;
  color: white;
  border: none;
  border-radius: 5px;
}
.hilight {
  color: #1823f3;
  border: 3px solid #1823f3 !important;
}
.filter {
  display: flex;
  gap: 10px;
  padding-left: 20px;
  padding: 20px;
}
.filter > label {
  display: block;
  border: 3px solid rgb(242, 238, 238);
  padding: 5px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 500;
  color: white;
}
.column tbody,
.bar tbody {
  overflow-y: hidden; /* remove this to see how it works */
}
.column tbody th,
.bar tbody th {
  z-index: 1;
}
.column tbody td {
  animation: moving-bars 2s linear forwards;
}
@keyframes moving-bars {
  0% {
    transform: translateY(100%);
  }
  30% {
    transform: translateY(0);
  }
}
.bar tbody td {
  animation: moving-barss 2s linear forwards;
}
@keyframes moving-barss {
  0% {
    transform: translatex(0);
  }
  30% {
    transform: translatex(-100%);
  }
}
#my-chart .column {
  --color: rgb(142, 142, 255);
}
.static {
  display: grid;
  grid-template-columns: 1fr 1fr;
  position: relative;
  gap: 30px;
  padding: 30px;
}
#my-chart {
  display: flex;
  width: 100%;
  background: rgb(255, 250, 250);
  box-shadow: 0 0 0 0.4px rgba(0, 0, 0, 0.427);
  border-radius: 20px;
}
.done {
  background: rgb(66, 167, 66) !important;
}
.wait {
  background: rgb(220, 220, 95) !important;
  color: black !important;
}
.actions {
  background: orange !important;
}
.not_pay {
  background: rgb(209, 133, 133) !important;
}
.parent {
  display: flex;
  padding: 20px;
  gap: 20px;
  flex-wrap: wrap;
}
.count > span,
.action > span {
  font-weight: 800;
  position: absolute;
  top: 10px;
  left: 10px;
  color: black;
}
.count,
.action {
  position: relative;
  padding: 20px;
  padding-top: 40px;
  display: flex;
  gap: 20px;
  border-radius: 10px;
  background: rgb(255, 255, 255);
  box-shadow: 0 0 0 0.4px rgba(0, 0, 0, 0.598);
}
.count > div {
  border-radius: 10px;
  width: 100px;
  height: 70px;
  background: gray;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 25px;
  font-weight: 900;
}
.count_tick {
  background: rgba(49, 106, 231, 0.852) !important;
}
.count_customer {
  background: rgba(31, 32, 95, 0.852) !important;
}
h3 {
  margin: 0;
  padding-left: 20px;
  padding-bottom: 10px;
}
</style>
