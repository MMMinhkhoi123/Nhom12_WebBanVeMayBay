<template>
  <div class="flight">
    <baseadd></baseadd>
    <div class="group_flight">
      <div class="filter">
        <!-- null  -->
      </div>
      <baselist></baselist>
      <baseloading
        v-if="$store.state.md_flight.status_send == true"
      ></baseloading>
    </div>
  </div>
</template>
<script>
import add from "@/components/Admin/Add/AddFlight.vue";
import list from "@/components/Admin/LIST/List_Flight.vue";
import loading from "@/components/Customer/Common/LoaDing.vue";
export default {
  components: {
    baseadd: add,
    baselist: list,
    baseloading: loading,
  },
  setup() {
    return {};
  },
};
</script>
<style scoped>
.search {
  position: relative;
}
.search > input {
  padding: 15px 30px;
  border-radius: 5px;
}
.icon {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 20px;
}
.flight {
  margin: 10px;
  margin-top: 10px;
  border-radius: 10px;
  background: rgb(255, 255, 255);
  overflow: hidden;
  padding: 10px;
}
.group_flight {
  background: rgb(255, 255, 255);
}
</style>
