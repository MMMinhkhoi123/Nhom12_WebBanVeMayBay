<template>
  <div class="mainlist">
    <div class="meta">
      <h3 @click="this.$router.go(-1)" class="title">
        <font-awesome-icon :icon="['fas', 'chevron-left']" /> Quay về
      </h3>
    </div>
    <div class="filter">
      <label>
        <input
          v-model="chonse"
          class="ip"
          type="radio"
          checked
          name="chose"
          :value="1"
        />
        <span>Chưa bay</span>
      </label>
      <label>
        <input
          v-model="chonse"
          class="ip"
          type="radio"
          name="chose"
          :value="2"
        />
        <span>Đã bay</span>
      </label>
      <label>
        <input
          v-model="chonse"
          class="ip"
          type="radio"
          name="chose"
          :value="3"
        />
        <span>Yêu cầu hủy</span>
      </label>
    </div>
    <div style="text-align: center">
      <p>Số lượng hiện có {{ array.length }}</p>
    </div>
    <div v-if="$store.state.list.history.length > 0" class="list">
      <div v-for="item in array" :key="item.id" class="itemtick">
        <div class="top">
          <div class="trademark">
            <img
              class="img"
              width="70"
              height="50"
              :src="
                'http://103.130.213.151:8081/img/trademark/' +
                item.trademark +
                '&3&' +
                item.imgtrademark
              "
            />
            <span>{{ item.nametrademark }}</span>
          </div>
          <div class="location">
            <span>Từ {{ item.locationgo }}</span>
            <span>Đến {{ item.locationfish }}</span>
          </div>
          <div class="time">
            <span>{{ culdate(item.timego) }}</span>
            <span>{{ culdate(item.timefish) }}</span>
          </div>
        </div>
        <div class="bottom">
          <div class="price">
            <span>{{ format(item.price) }}</span>
          </div>
          <div class="setting">
            <div class="timeby">
              <span>Ngày mua: </span>
              <span
                >{{ culdate(item.timemua) }}
                <font-awesome-icon class="icon" :icon="['fas', 'check']"
              /></span>
            </div>
            <button
              @click="requid_destroy(item.id)"
              v-if="
                check_tick_action(item.timego) == true &&
                item.status == 'Hoạt động' &&
                check_date(item.date_use) == false
              "
            >
              <p v-if="check_date(item.date_use) == false">Hủy vé</p>
            </button>
            <button
              style="opacity: 0.6"
              v-if="
                check_date(item.date_use) == true && item.status == 'Hoạt động'
              "
            >
              <p>Có thể hủy vé sau 1 tiếng</p>
            </button>
          </div>
          <div v-if="item.status == 'Yêu cầu hủy'" class="setting">
            <span style="color: red">Chờ Hoàn tiền</span>
            <button @click="requid_restore(item.id)">Hủy yêu cầu</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import store from "@/store";
import { computed, ref } from "vue";
export default {
  setup() {
    const culdate = (value) => {
      const dates = new Date(value);
      const minu = dates.getMinutes();
      const hour = dates.getHours();
      return (
        hour +
        ":" +
        minu +
        "  " +
        dates.getDate() +
        "/" +
        (dates.getUTCMonth() + 1) +
        "/" +
        dates.getFullYear()
      );
    };
    const check_tick_action = (value) => {
      const date = new Date(value);
      if (value < new Date().getTime()) {
        return false;
      }
      if (date.getMonth() == new Date().getMonth()) {
        if (Number(date.getDate()) - Number(new Date().getDate()) <= 1) {
          return false;
        }
      }
      return true;
    };
    const array = computed(() => {
      if (chonse.value == "2") {
        return store.state.list.history.filter(
          (e) => e.timego < new Date().getTime()
        );
      }
      if (chonse.value == "3") {
        return store.state.list.history.filter(
          (e) => e.timego > new Date().getTime() && e.status == "Yêu cầu hủy"
        );
      }
      return store.state.list.history.filter(
        (e) => e.timego > new Date().getTime() && e.status == "Hoạt động"
      );
    });
    const requid_destroy = (id) => {
      const date = new Date();
      date.setHours(Number(date.getHours()) + 1);
      const data = {
        id: id,
        date: date.getTime(),
      };
      store.dispatch("list/requid_destroy", data);
    };
    const check_date = (value) => {
      if (new Date().getTime() < value) {
        return true;
      }
      return false;
    };
    const requid_restore = (id) => {
      store.dispatch("list/requid_restore", id);
    };
    const chonse = ref(null);
    const VND = new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    });

    const format = (value) => {
      return VND.format(value);
    };
    return {
      culdate,
      array,
      chonse,
      check_tick_action,
      requid_destroy,
      requid_restore,
      check_date,
      format,
    };
  },
};
</script>
<style scoped>
.setting {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
}
.setting > button {
  background: rgb(255, 153, 0);
  border: none;
  border-radius: 10px;
  font-weight: 700;
  padding: 6px 30px;
  cursor: pointer;
}
.ip:checked ~ span {
  color: red;
}
.ip {
  display: none;
}
.filter {
  justify-content: center;
  display: flex;
  gap: 20px;
  padding: 20px;
  font-weight: 700;
}
.filter > label {
  cursor: pointer;
}
.trademark {
  display: flex;
  justify-content: center;
  gap: 10px;
  align-items: center;
  font-weight: 800;
}
.list {
  margin: 30px 200px;
  padding: 20px 20px;
  height: 500px;
  overflow-y: scroll;
}
/* tick  */
.icon {
  color: rgb(89, 206, 89);
}
image {
  width: 50px;
  height: 50px;
}
.itemtick {
  background: rgb(250, 250, 252);
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.457);
  border-radius: 10px;
  margin: 10px 0;
}
.time,
.location {
  display: flex;
  gap: 10px;
}
.top,
.bottom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
}
/* end tick */
.meta {
  background: rgb(68, 91, 202);
  text-align: start;
}
.mainlist {
  border-radius: 10px;
  overflow: hidden;
  margin-top: 10px;
  min-height: 100vh;
  position: relative;
  z-index: 10;
  background: white;
}
.title {
  margin: 0;
  padding: 20px;
  cursor: pointer;
}
</style>
