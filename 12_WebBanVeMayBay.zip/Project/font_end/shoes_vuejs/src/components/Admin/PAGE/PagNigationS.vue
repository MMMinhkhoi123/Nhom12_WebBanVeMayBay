<template>
  <h1>Minh Khoi</h1>
</template>
<script>
export default {
  props: {
    toltal_page: Number,
  },
  setup(props) {
    console.log(props.array);
    return {};
  },
};
</script>
<style scoped>
.grou_page {
  display: flex;
}
</style>
