<template>
  <div class="list_flight">
    <table id="customers">
      <tr>
        <th>Mã máy bay</th>
        <th>Sân bay</th>
        <th>Điêm xuất phát</th>
        <th>Điêm đến</th>
        <th>Giờ khởi hành</th>
        <th>Giờ đến dự kiến</th>
        <th>Giá vé</th>
        <th>Tùy chỉnh</th>
      </tr>
      <tr v-for="item in list.list" :key="item.id">
        <td v-if="$store.state.md_airplane.airplane.length > 0">
          {{
            $store.getters["md_airplane/getairplaneid"](item.id_airplane)[0] ==
            null
              ? null
              : $store.getters["md_airplane/getairplaneid"](item.id_airplane)[0]
                  .name
          }}
        </td>
        <td v-if="$store.state.md_airfield.airfield.length > 0">
          {{
            $store.getters["md_airfield/getairfieldid"](item.id_airfield)[0]
              .name
          }}
        </td>
        <td v-if="$store.state.md_location.Location.length > 0">
          {{
            $store.getters["md_location/getlocationid"](
              item.id_location_departure
            )[0].name
          }}
        </td>
        <td v-if="$store.state.md_location.Location.length > 0">
          {{
            $store.getters["md_location/getlocationid"](
              item.id_location_complete
            )[0].name
          }}
        </td>
        <td>
          {{ converttime(item.date_departure) }}
        </td>
        <td>
          {{ converttime(item.date_complete) }}
        </td>
        <td>
          {{ format(item.price) }}
        </td>
        <td class="setting">
          <button
            v-if="item.status == 'Đã hoạt động'"
            @click="update(item.id)"
            class="delay"
          >
            <font-awesome-icon :icon="['fas', 'plane-slash']" /> Delay
          </button>
          <button
            v-if="item.status == 'Chưa hoạt động'"
            @click="update(item.id)"
            class="edit"
          >
            <font-awesome-icon :icon="['fas', 'pen-to-square']" /> edit
          </button>
          <button @click="deletes(item.id)" class="remove">
            <font-awesome-icon :icon="['fas', 'trash']" /> Delete
          </button>
        </td>
      </tr>
    </table>

    <!-- phân trang -->
    <div class="group_page">
      <div
        @click="chagepage($store.state.md_flight.page.page - 1)"
        v-if="$store.state.md_flight.page.page > 1"
        class="item_page"
      >
        <font-awesome-icon :icon="['fas', 'chevron-left']" />
      </div>
      <div v-for="item in list.toltalpage" :key="item">
        <div
          @click="chagepage(item)"
          :style="
            item == list.page ? { background: 'blue', color: 'white' } : null
          "
          class="item_page"
        >
          {{ item }}
        </div>
      </div>
      <div
        @click="chagepage($store.state.md_flight.page.page + 1)"
        v-if="list.page < list.toltalpage"
        class="item_page"
      >
        <font-awesome-icon :icon="['fas', 'chevron-right']" />
      </div>
    </div>
  </div>
  <!-- Thông báo ở đây 
   -->
  <div
    @click="data_remove.status = false"
    :class="data_remove.status == false ? null : 'show'"
    class="bg_black"
  ></div>
  <basenotification :class="data_remove.status == false ? null : 'show_from'">
    <template #content>
      <p>Bạn có Chắc xóa chuyến bai này không ?</p>
    </template>
    <template #button>
      <button @click="submit_delete" class="remove">
        <font-awesome-icon :icon="['fas', 'trash']" /> Xóa
      </button>
      <button @click="data_remove.status = false" class="close">
        <font-awesome-icon :icon="['fas', 'xmark']" />
        Close
      </button>
    </template>
  </basenotification>
  <!-- mess -->
  <!-- // mess -->
  <basemes
    :class="$store.state.md_flight.mess_flight == null ? null : 'show_mess'"
    :style="
      $store.state.md_flight.status_flight == 0
        ? { background: 'rgb(118, 226, 118)' }
        : $store.state.md_flight.status_flight == 1
        ? { background: 'yellow' }
        : { background: 'red' }
    "
  >
    <template #content>
      <p>{{ $store.state.md_flight.mess_flight }}</p>
    </template>
  </basemes>
  <!-- end mess -->
</template>
<script>
import store from "@/store";
import mess from "@/components/Admin/NOTI/MessVue.vue";
import notification from "../NOTI/DeleteVue.vue";
import { computed, reactive } from "vue";
export default {
  components: {
    basemes: mess,
    basenotification: notification,
  },
  setup() {
    store.state.md_flight.mess_flight = null;
    store.dispatch("md_flight/get_flight");
    store.dispatch("md_flight/get_all_flight");
    const list = computed(() => {
      return store.state.md_flight.flight;
    });
    const converttime = (value) => {
      const date = new Date(value);
      return (
        date.getHours() +
        "h" +
        date.getMinutes() +
        "p   " +
        date.getDate() +
        "-" +
        (Number(date.getMonth()) + 1) +
        "-" +
        date.getFullYear()
      );
    };
    const update = (value) => {
      if (store.getters["md_flight/getfligthid"](value)) {
        store.state.md_flight.data_check.price =
          store.getters["md_flight/getfligthid"](value).price;
        store.state.md_flight.data_check.id_airplane =
          store.getters["md_flight/getfligthid"](value).id_airplane;
        store.state.md_flight.data_check.id_locationgo =
          store.getters["md_flight/getfligthid"](value).id_location_departure;
        store.state.md_flight.data_check.id_locationand =
          store.getters["md_flight/getfligthid"](value).id_location_complete;
        store.state.md_flight.data_check.id_airfield =
          store.getters["md_flight/getfligthid"](value).id_airfield;
        store.state.md_flight.data_check.id =
          store.getters["md_flight/getfligthid"](value).id;
      }
      const datago = new Date(
        store.getters["md_flight/getfligthid"](value).date_departure
      );
      const datacomne = new Date(
        store.getters["md_flight/getfligthid"](value).date_complete
      );
      store.state.md_flight.data_check.delay =
        store.getters["md_flight/getfligthid"](value).status;
      store.state.md_flight.data_check.timemove = convert_time(datacomne);
      store.state.md_flight.data_check.timego = convert_time(datago);
      store.state.md_flight.data_check.date_go = convert_times(datago);
      store.state.md_flight.data_check.date_move = convert_times(datacomne);
    };
    const convert_times = (datago) => {
      var month = Number(datago.getMonth()) + 1;
      var data = datago.getDate();
      if (datago.getMonth().toString().length == 1) {
        month = "0" + datago.getMonth();
      }
      if (datago.getDate().toString().length == 1) {
        data = "0" + datago.getDate();
      }
      return (
        datago.getFullYear().toString() +
        "-" +
        month.toString() +
        "-" +
        data.toString()
      );
    };
    const convert_time = (datago) => {
      var hour = datago.getHours();
      var miu = datago.getMinutes();
      if (hour.toString().length == 1) {
        hour = "0" + datago.getHours();
      }
      if (miu.toString().length == 1) {
        miu = "0" + datago.getMinutes();
      }
      return hour.toString() + ":" + miu.toString();
    };
    const data_remove = reactive({
      id: null,
      status: false,
    });

    const deletes = (id) => {
      data_remove.status = true;
      data_remove.id = id;
    };

    const submit_delete = () => {
      data_remove.status = false;
      store.state.md_flight.mess_flight = null;
      store.dispatch("md_flight/delete_flight", data_remove.id);
      setTimeout(() => {
        if (store.state.md_flight.mess_flight == null) {
          store.state.md_flight.mess_flight = "Delete  flight success !";
        }
      }, 300);
    };
    const chagepage = (item) => {
      store.state.md_flight.page.page = item;
      //get
      store.dispatch("md_flight/get_flight");
    };
    const VND = new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    });

    const format = (value) => {
      return VND.format(value);
    };
    return {
      data_remove,
      list,
      converttime,
      update,
      deletes,
      submit_delete,
      chagepage,
      format,
    };
  },
};
</script>
<style scoped>
.delay {
  background: orangered;
}
.delete {
  background: rgba(255, 28, 28, 0.779);
}
.setting {
  text-align: center;
}
.setting > button {
  padding: 10px 20px;
  border: none;
  margin: 0 5px;
  color: rgb(255, 255, 255);
  font-weight: 700;
  border-radius: 4px;
}
/* table  */
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
#customers td,
#customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even) {
  background-color: #f2f2f2;
}

#customers tr:hover {
  background-color: #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12rgb (12, 175, 115);
  text-align: left;
  background-color: #3024de;
  color: white;
}
/* end table */
/* pageagtion */
/* pagnigation */

.group_page {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
  position: absolute;
  right: 10px;
  bottom: 10px;
}
.item_page {
  display: flex;
  justify-content: center;
  align-items: center;
  background: white;
  width: 40px;
  height: 40px;
  border-radius: 10px;
  border: 1px solid gray;
  cursor: pointer;
}
/* notication */
/* Notofication  */
.remove,
.close {
  border: none;
  padding: 10px 20px;
  color: white;
  border-radius: 5px;
  cursor: pointer;
}
.remove {
  background: red;
}
.close {
  background: orange;
}
.bg {
  position: fixed;
  inset: 0;
}
.bg_black {
  position: fixed;
  inset: 0;
  transition: 0.3s;
  background: rgba(0, 0, 0, 0.18);
  opacity: 0;
  pointer-events: none;
}
.show {
  opacity: 1 !important;
  pointer-events: visible !important;
}
.show_from {
  top: 50% !important;
  opacity: 1 !important;
}
/* end notication */
/* mess */

/* mess */
.show_mess {
  animation: showmess 2s ease-in forwards;
}
@keyframes showmess {
  0% {
    opacity: 0;
  }
  70% {
    opacity: 1;
  }
  100% {
    opacity: 0 !important;
  }
}
/* mess */
.edit {
  background: blue;
}
.remove {
  background: red;
}
.list_flight {
  background: white;
  position: relative;
  padding-bottom: 60px;
}

.item {
  margin: 5px;
  display: flex;
  justify-content: space-between;
  background: rgb(255, 255, 255);
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.422);
}
.top {
  grid: a;
}
.bottom {
  grid: b;
}
.end {
  grid: c;
}

.top > span,
.end > span,
.bottom > span {
  padding: 10px;
}
.top,
.bottom {
  display: flex;
  justify-content: space-around;
}
.end {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10px;
  gap: 10px;
}
button {
  padding: 10px 20px;
  color: white;
  font-weight: 600;
  border: none;
  border-radius: 10px;
  cursor: pointer;
}
</style>
