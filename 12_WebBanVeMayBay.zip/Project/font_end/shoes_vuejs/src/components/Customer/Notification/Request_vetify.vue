<template>
  <div class="bg"></div>
  <form @submit.prevent="onsubmit()" class="from_vetify">
    <h3>Bạn chưa có tài khoản, để tếp tục vui lòng xác thực email</h3>
    <p>
      Thứ lỗi vì điều này , mục đích của việc này là để bảo đảm bạn nhận được vé
      điện tử sau khi thanh toan, Hoặc có thể <strong>Đăng nhập</strong>
    </p>
    <div v-if="!status" class="from">
      <p v-if="dataurl != 'null'">
        {{ email == undefined ? "Xác thực hết hạn " : "Đã xác thực "
        }}<strong>{{ dataurl }}</strong>
      </p>
      <label
        @click="
          this.$router.push({ name: 'booking', query: this.$route.query })
        "
        for=""
        >Nhập gmail nhận vé điện tử</label
      >
      <input v-model="data" type="email" />
      <div class="setting">
        <span v-if="err" class="err">{{ err }}</span>
        <button type="submit">Xác thực</button>
      </div>
    </div>
    <div class="notu" v-if="status && $store.state.post.status_verify == null">
      <p>Đã gửi yêu cầu xác thực .</p>
      <span>hoặc <strong @click="this.$router.go()"> Đổi email</strong></span>
    </div>
  </form>
  <baseLoaDing v-if="$store.state.post.status_verify != null"></baseLoaDing>
</template>
<script>
import LoaDing from "../Common/LoaDing.vue";
import { computed, ref } from "vue";
import store from "@/store";
import router from "@/router";
export default {
  components: {
    baseLoaDing: LoaDing,
  },
  setup() {
    const err = ref(false);
    const data = ref(null);
    const status = ref(false);
    const dataurl = computed(() => {
      return localStorage.getItem("vetify_email");
    });
    const onsubmit = () => {
      if (data.value == null) {
        err.value = "Không bỏ trống";
      } else {
        err.value = null;
        status.value = true;
        localStorage.clear();
        localStorage.setItem("vetify_email", data.value);
        // xác thực
        store.state.post.status_verify = 1;
        store.dispatch("post/vetify", data.value);

        var time = 2 * 60 * 1000;
        setTimeout(() => {
          const y = setInterval(() => {
            store.dispatch("post/get_status_vetify2");
            if (store.state.post.status_regiter == 8 || time <= 2000) {
              clearInterval(y);
              store.state.post.status_regiter = null;
              localStorage.setItem("gmail", data.value);
              router.go();
            }
            time = time - 2000;
          }, 2000);
        }, 2000);
      }
    };
    const email = computed(() => {
      return localStorage.getItem("gmail");
    });
    const clear = () => {
      localStorage.clear();
    };
    return { onsubmit, err, dataurl, data, clear, status, email };
  },
};
</script>
<style scoped>
.notu {
  padding: 20px;
}
.err {
  color: red;
}
.from {
  display: flex;
  padding: 20px;
  text-align: start;
  flex-direction: column;
  gap: 10px;
}
.from > input {
  padding: 10px;
  border-radius: 5px;
}
.bg {
  position: fixed;
  inset: 0;
  z-index: 99;
  background: rgba(14, 14, 14, 0.195);
  animation: hiden 1s ease forwards;
}
@keyframes hiden {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
.from_vetify {
  width: 450px;
  background: rgb(239, 239, 239);
  position: fixed;
  z-index: 100;
  top: 20px;
  left: calc(50% - 250px);
  border-radius: 5px;
  animation: show 1s ease forwards;
}

@keyframes show {
  0% {
    top: -100px;
  }
  100% {
    top: 20px;
  }
}
.setting {
  display: flex;
  gap: 30px;
  justify-content: end;
  align-items: center;
}
.setting > button {
  padding: 8px 20px;
  background: rgb(255, 132, 0);
  border: none;
  border-radius: 5px;
  color: white;
}
p {
  margin: 0;
}
</style>
